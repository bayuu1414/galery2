<?php

require "../koneksi.php";

$id = $_POST['album_id'];
$nama = $_POST['nama_album'];
$deskripsi = $_POST['deskripsi_album'];
$tanggal = $_POST['tanggal_dibuat'];
$iduser = $_POST['user_id'];

$sql = "UPDATE tb_album SET nama_album = '$nama', deskripsi_album = '$deskripsi', tanggal_dibuat = '$tanggal' WHERE album_id = '$id'";

$result = $conn->query($sql);
if(!$result){
    die ("Ada kesalhan : " .$conn->error);
}
if($conn->affected_rows){
    header("location:../album/album.php");
}

?>