# web_galeri_foto-ujikom
membuat website galeri untuk uji kompentensi di jurusan RPL

bahasa yang saya pakai yaitu 
1. PHP
2. Java script ( boleh pakai boleh g )
3. bootstrap

sebelum pakai silahkan upload database mysql terlebih dahulu

![Screenshot 2024-02-17 105318](https://github.com/dffhaa/web_galeri_foto-ujikom/assets/134750606/7bf46a84-e315-4588-809b-1aad2d4940e3)

![Screenshot 2024-02-17 105455](https://github.com/dffhaa/web_galeri_foto-ujikom/assets/134750606/ac9362e2-dbbe-43e2-ba4d-734d12c4c6e8)

![Screenshot 2024-02-17 105440](https://github.com/dffhaa/web_galeri_foto-ujikom/assets/134750606/ebe4a2a6-abc4-47b0-9207-57b33885674b)

![Screenshot 2024-02-17 105426](https://github.com/dffhaa/web_galeri_foto-ujikom/assets/134750606/78ef9ae5-316d-402f-b22d-a84bfe1123fb)
